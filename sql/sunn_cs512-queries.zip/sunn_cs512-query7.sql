-- Insert Felix Gaeta with an age of 28 into the bsg_people table

INSERT INTO bsg_people (fname, lname, age) VALUES ('Felix', 'Gaeta', 28)

